import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.chdir(os.path.dirname(__file__))

print("1. Testing database layer...")
from utils.database import initialize_db, load_patients, load_doctors, load_appointments
initialize_db()
p = load_patients()
d = load_doctors()
a = load_appointments()
print(f"   Patients: {len(p)}, Doctors: {len(d)}, Appointments: {len(a)}")

print("2. Training ML model...")
from models.predictor import train_model, predict_no_show_risk, get_model_metrics
model = train_model()
print("   Model trained OK")

print("3. Running prediction test...")
result = predict_no_show_risk(
    age=45, previous_no_shows=2, booking_lead_days=10,
    distance_km=15.5, sms_reminder_sent=True,
    chronic_conditions="Hypertension", appointment_time="10:00",
    appointment_date="2025-08-01"
)
print(f"   Score: {result['risk_score']}, Label: {result['risk_label']}")
print(f"   Factors: {result['risk_factors']}")
print(f"   Recommendation: {result['recommendation'].encode('ascii','replace').decode()}")

print("4. Computing model metrics...")
metrics = get_model_metrics()
print(f"   Accuracy: {metrics['accuracy']}%, ROC-AUC: {metrics['roc_auc']}%")
print(f"   Precision: {metrics['precision']}%, Recall: {metrics['recall']}%")

print()
print("All tests passed!")
