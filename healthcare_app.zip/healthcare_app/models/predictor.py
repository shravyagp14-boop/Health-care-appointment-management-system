"""
ML-based No-Show Risk Predictor
Uses a Random Forest classifier trained on synthetic patient history.
Features: age, previous_no_shows, booking_lead_days, distance_km,
          sms_reminder_sent, hour_of_day, day_of_week, is_chronic
"""

import os
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.calibration import CalibratedClassifierCV

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "noshow_model.pkl")


def _extract_features(df: pd.DataFrame) -> pd.DataFrame:
    """Convert raw appointment + patient columns to ML feature matrix."""
    feat = pd.DataFrame()
    feat["age"]                 = pd.to_numeric(df.get("age", 30), errors="coerce").fillna(30)
    feat["previous_no_shows"]   = pd.to_numeric(df.get("previous_no_shows", 0), errors="coerce").fillna(0)
    feat["booking_lead_days"]   = pd.to_numeric(df.get("booking_lead_days", 7), errors="coerce").fillna(7)
    feat["distance_km"]         = pd.to_numeric(df.get("distance_km", 10), errors="coerce").fillna(10)
    feat["sms_reminder_sent"]   = df.get("sms_reminder_sent", True).astype(int)
    feat["is_chronic"]          = df.get("chronic_conditions", "None").apply(
                                      lambda x: 0 if str(x).strip().lower() in ("none", "", "nan") else 1)
    # time-based features
    if "appointment_time" in df.columns:
        feat["hour_of_day"] = df["appointment_time"].apply(
            lambda t: int(str(t).split(":")[0]) if pd.notna(t) else 10
        )
    else:
        feat["hour_of_day"] = 10

    if "appointment_date" in df.columns:
        feat["day_of_week"] = pd.to_datetime(df["appointment_date"], errors="coerce").dt.dayofweek.fillna(0).astype(int)
    else:
        feat["day_of_week"] = 0

    # age buckets
    feat["age_bucket"] = pd.cut(feat["age"], bins=[0,25,45,65,120], labels=[0,1,2,3]).astype(int)
    # interaction
    feat["risk_interaction"] = feat["previous_no_shows"] * feat["booking_lead_days"]

    return feat


def _generate_training_data(n=5000):
    """Generate synthetic training data that mirrors the seeding heuristic."""
    rng = np.random.RandomState(42)
    age              = rng.randint(18, 80, n)
    prev_ns          = rng.choice([0,1,2,3,4,5], p=[0.40,0.25,0.15,0.10,0.06,0.04], size=n)
    lead_days        = rng.randint(1, 31, n)
    dist             = rng.uniform(1, 50, n)
    sms              = rng.randint(0, 2, n)
    is_chronic       = rng.randint(0, 2, n)
    hour             = rng.choice([9,10,11,14,15,16,17], n)
    dow              = rng.randint(0, 7, n)

    # probability formula for label generation
    p = (
        0.05
        + prev_ns * 0.10
        + (lead_days > 14).astype(float) * 0.08
        + (lead_days > 7).astype(float)  * 0.04
        + (dist > 30).astype(float)      * 0.08
        + (dist > 15).astype(float)      * 0.04
        + (1 - sms)                      * 0.07
        + ((age < 25) | (age > 65)).astype(float) * 0.04
        + (dow >= 5).astype(float)       * 0.03   # weekends
        + (hour >= 15).astype(float)     * 0.02   # afternoon
    )
    p = np.clip(p, 0, 0.95)
    labels = (rng.random(n) < p).astype(int)

    df = pd.DataFrame({
        "age": age, "previous_no_shows": prev_ns,
        "booking_lead_days": lead_days, "distance_km": dist,
        "sms_reminder_sent": sms, "is_chronic": is_chronic,
        "hour_of_day": hour, "day_of_week": dow,
        "age_bucket": pd.cut(age, bins=[0,25,45,65,120], labels=[0,1,2,3]).astype(int),
        "risk_interaction": prev_ns * lead_days,
    })
    return df, labels


def train_model() -> Pipeline:
    X, y = _generate_training_data(6000)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    base = GradientBoostingClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.08,
        subsample=0.8, min_samples_leaf=20, random_state=42
    )
    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", CalibratedClassifierCV(base, cv=3, method="isotonic")),
    ])
    pipeline.fit(X_train, y_train)
    joblib.dump(pipeline, MODEL_PATH)
    return pipeline


def load_model() -> Pipeline:
    if not os.path.exists(MODEL_PATH):
        return train_model()
    try:
        return joblib.load(MODEL_PATH)
    except Exception:
        return train_model()


def predict_no_show_risk(
    age: int,
    previous_no_shows: int,
    booking_lead_days: int,
    distance_km: float,
    sms_reminder_sent: bool,
    chronic_conditions: str = "None",
    appointment_time: str = "10:00",
    appointment_date: str = None,
) -> dict:
    """
    Returns dict with:
      - risk_score (0-100 float)
      - risk_label (Low / Medium / High)
      - risk_factors (list of human-readable strings)
      - recommendation (string)
    """
    model = load_model()

    row = pd.DataFrame([{
        "age": age,
        "previous_no_shows": previous_no_shows,
        "booking_lead_days": booking_lead_days,
        "distance_km": distance_km,
        "sms_reminder_sent": int(sms_reminder_sent),
        "chronic_conditions": chronic_conditions,
        "appointment_time": appointment_time,
        "appointment_date": appointment_date or pd.Timestamp.today().strftime("%Y-%m-%d"),
    }])

    features = _extract_features(row)
    prob = model.predict_proba(features)[0][1]   # probability of no-show
    score = round(prob * 100, 1)

    # Risk label
    if score >= 65:
        label = "High"
    elif score >= 35:
        label = "Medium"
    else:
        label = "Low"

    # Human-readable risk factors
    factors = []
    if previous_no_shows >= 3:
        factors.append(f"High prior no-show history ({previous_no_shows} missed appointments)")
    elif previous_no_shows >= 1:
        factors.append(f"Some prior no-shows ({previous_no_shows} missed appointments)")
    if booking_lead_days > 14:
        factors.append(f"Long booking lead time ({booking_lead_days} days ahead)")
    if distance_km > 30:
        factors.append(f"Long travel distance ({distance_km:.1f} km)")
    if not sms_reminder_sent:
        factors.append("No SMS reminder scheduled")
    if age < 25 or age > 65:
        factors.append(f"Age group ({age} yrs) has elevated no-show tendency")
    if not factors:
        factors.append("No significant risk factors detected")

    # Recommendation
    if label == "High":
        rec = "📞 Call patient to confirm. Send SMS reminder. Consider overbooking slot."
    elif label == "Medium":
        rec = "📱 Send SMS reminder 48 hrs before. Follow-up call day before."
    else:
        rec = "✅ Standard appointment. Send routine reminder."

    return {
        "risk_score": score,
        "risk_label": label,
        "risk_factors": factors,
        "recommendation": rec,
    }


def batch_predict(df: pd.DataFrame) -> pd.DataFrame:
    """Predict risk for a DataFrame of appointments + patient attributes."""
    model = load_model()
    features = _extract_features(df)
    probs = model.predict_proba(features)[:, 1]
    scores = (probs * 100).round(1)
    labels = pd.cut(scores, bins=[-1, 34.9, 64.9, 100],
                    labels=["Low", "Medium", "High"])
    df = df.copy()
    df["no_show_risk"] = scores
    df["risk_label"]   = labels
    return df


def get_model_metrics() -> dict:
    """Return accuracy metrics on held-out test set."""
    from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
    model = load_model()
    X, y  = _generate_training_data(6000)
    _, X_test, _, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    preds = model.predict(X_test)
    probs = model.predict_proba(X_test)[:, 1]
    report = classification_report(y_test, preds, output_dict=True)
    return {
        "accuracy":  round(accuracy_score(y_test, preds) * 100, 1),
        "roc_auc":   round(roc_auc_score(y_test, probs) * 100, 1),
        "precision": round(report["1"]["precision"] * 100, 1),
        "recall":    round(report["1"]["recall"] * 100, 1),
    }
