"""
Page 3 – No-Show Risk Predictor (standalone interactive tool)
Doctors and staff can interactively assess no-show risk for any patient
before or after booking, and get Gemini-powered intervention advice.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import date

from utils.database import load_patients, get_patient_appointments, get_patient_no_show_count
from models.predictor import predict_no_show_risk, batch_predict
from utils.gemini_helper import explain_risk


def _gauge_chart(score, label):
    color_map = {"Low": "#22c55e", "Medium": "#f59e0b", "High": "#ef4444"}
    fig = go.Figure(go.Indicator(
        mode   = "gauge+number+delta",
        value  = score,
        delta  = {"reference": 50, "increasing": {"color": "#ef4444"}, "decreasing": {"color": "#22c55e"}},
        gauge  = {
            "axis":  {"range": [0, 100], "tickwidth": 1},
            "bar":   {"color": color_map.get(label, "#3b82d4")},
            "steps": [
                {"range": [0,  34], "color": "#d5f5d5"},
                {"range": [35, 64], "color": "#fffacc"},
                {"range": [65,100], "color": "#ffd5d5"},
            ],
            "threshold": {
                "line": {"color": "black", "width": 3},
                "thickness": 0.8,
                "value": score,
            }
        },
        title  = {"text": f"No-Show Risk Score<br><b>{label} Risk</b>"}
    ))
    fig.update_layout(height=280, margin=dict(t=40, b=10, l=20, r=20))
    return fig


def show():
    st.title("🔮 No-Show Risk Predictor")
    st.markdown(
        "Assess the probability of a patient missing their appointment using our "
        "Gradient Boosting ML model, then get AI-powered intervention recommendations."
    )

    api_key = st.session_state.get("gemini_api_key", "")

    tab1, tab2, tab3 = st.tabs(["🧑 Individual Assessment", "📋 Batch Assessment", "📊 Historical Analysis"])

    # ════════════════════════════════════════════════════════════════════════
    # TAB 1 – Individual
    # ════════════════════════════════════════════════════════════════════════
    with tab1:
        st.subheader("Individual Patient Risk Assessment")

        patients_df = load_patients()
        use_existing = st.toggle("Load from existing patient", value=True)

        col_left, col_right = st.columns([1, 1], gap="large")

        with col_left:
            st.markdown("#### Patient & Appointment Details")

            if use_existing and not patients_df.empty:
                names     = patients_df["name"].tolist()
                sel_name  = st.selectbox("Select Patient", names)
                patient   = patients_df[patients_df["name"] == sel_name].iloc[0]
                prev_ns   = get_patient_no_show_count(patient["patient_id"])

                patient_name = patient["name"]
                age          = int(patient["age"])
                chronic      = str(patient.get("chronic_conditions","None"))
                st.info(
                    f"**Age:** {age} &nbsp;|&nbsp; "
                    f"**Conditions:** {chronic}  \n"
                    f"**Previous No-Shows:** {prev_ns}"
                )
            else:
                patient_name = st.text_input("Patient Name", "New Patient")
                age          = st.number_input("Age", min_value=1, max_value=120, value=35)
                prev_ns      = st.number_input("Previous No-Shows", min_value=0, max_value=20, value=0)
                chronic      = st.text_input("Chronic Conditions", "None")

            # Appointment details
            appt_date  = st.date_input("Appointment Date", min_value=date.today())
            appt_time  = st.selectbox("Appointment Time",
                                      ["08:00","09:00","10:00","11:00","12:00",
                                       "14:00","15:00","16:00","17:00"])
            lead_days  = (appt_date - date.today()).days
            st.caption(f"📅 Booking lead time: **{lead_days} days**")

            distance   = st.slider("Distance from Clinic (km)", 1, 60, 10)
            sms        = st.checkbox("SMS Reminder Will Be Sent", value=True)

            predict_btn = st.button("🔮 Predict No-Show Risk", use_container_width=True, type="primary")

        with col_right:
            if predict_btn:
                with st.spinner("Running ML model…"):
                    result = predict_no_show_risk(
                        age              = age,
                        previous_no_shows= int(prev_ns),
                        booking_lead_days= lead_days,
                        distance_km      = distance,
                        sms_reminder_sent= sms,
                        chronic_conditions= chronic,
                        appointment_time = appt_time,
                        appointment_date = appt_date.isoformat(),
                    )

                # Gauge
                st.plotly_chart(_gauge_chart(result["risk_score"], result["risk_label"]),
                                use_container_width=True)

                # Risk factors
                st.markdown("#### 📋 Risk Factors")
                for f in result["risk_factors"]:
                    icon = "⚠️" if result["risk_label"] != "Low" else "ℹ️"
                    st.markdown(f"{icon} {f}")

                st.markdown("---")
                st.markdown(f"**💡 Recommendation:**  \n{result['recommendation']}")

                # Gemini explanation
                if api_key:
                    st.markdown("---")
                    with st.spinner("🤖 Getting AI intervention advice from Gemini 2.5 Flash…"):
                        ai_advice = explain_risk(
                            api_key, patient_name,
                            result["risk_score"], result["risk_label"],
                            result["risk_factors"], result["recommendation"]
                        )
                    st.markdown("#### 🤖 AI Intervention Advice")
                    st.markdown(ai_advice)
                else:
                    st.info("💡 Enter your Gemini API key in the sidebar for AI-powered intervention advice.")
            else:
                st.markdown("#### 📊 Risk Score Gauge")
                st.markdown("Configure patient details and click **Predict No-Show Risk**.")
                placeholder_fig = _gauge_chart(0, "Low")
                st.plotly_chart(placeholder_fig, use_container_width=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 2 – Batch Assessment
    # ════════════════════════════════════════════════════════════════════════
    with tab2:
        st.subheader("Batch Risk Assessment — All Upcoming Appointments")
        st.markdown(
            "Automatically score all upcoming scheduled appointments "
            "and prioritize patients needing intervention."
        )

        from utils.database import load_appointments
        appts = load_appointments()
        today = pd.Timestamp(date.today())
        upcoming = appts[
            (appts["status"] == "Scheduled") &
            (appts["appointment_date"] >= today)
        ].copy()

        if upcoming.empty:
            st.info("No upcoming scheduled appointments found.")
        else:
            # Merge patient chronic conditions
            if not patients_df.empty:
                upcoming = upcoming.merge(
                    patients_df[["patient_id","age","chronic_conditions"]],
                    on="patient_id", how="left", suffixes=("","_p")
                )
                if "age_p" in upcoming.columns:
                    upcoming["age"] = upcoming["age_p"].fillna(upcoming["age"])
                if "chronic_conditions" not in upcoming.columns:
                    upcoming["chronic_conditions"] = "None"
                upcoming["chronic_conditions"] = upcoming["chronic_conditions"].fillna("None")
            else:
                upcoming["chronic_conditions"] = "None"

            with st.spinner("Running batch risk prediction…"):
                scored = batch_predict(upcoming)

            # Summary
            s1, s2, s3, s4 = st.columns(4)
            s1.metric("Total Upcoming",  len(scored))
            s2.metric("🔴 High Risk",    int((scored["risk_label"]=="High").sum()))
            s3.metric("🟡 Medium Risk",  int((scored["risk_label"]=="Medium").sum()))
            s4.metric("🟢 Low Risk",     int((scored["risk_label"]=="Low").sum()))

            st.markdown("---")
            # Priority table
            display = scored[[
                "appointment_id","patient_name","doctor_name","department",
                "appointment_date","appointment_time","no_show_risk","risk_label",
                "previous_no_shows","distance_km","sms_reminder_sent"
            ]].copy()
            display["appointment_date"] = display["appointment_date"].dt.strftime("%d %b %Y")
            display["no_show_risk"] = display["no_show_risk"].round(1)
            display = display.sort_values("no_show_risk", ascending=False)
            display.columns = ["ID","Patient","Doctor","Dept","Date","Time",
                                "Risk Score","Risk","Prev NS","Dist km","SMS"]

            def _hl(val):
                c = {"High":"#ffd5d5","Medium":"#fffacc","Low":"#d5f5d5"}
                return f"background-color: {c.get(val,'')}"

            st.dataframe(
                display.style.applymap(_hl, subset=["Risk"]),
                use_container_width=True, hide_index=True, height=400
            )

            st.download_button(
                "⬇️ Export Risk Report",
                data=display.to_csv(index=False).encode(),
                file_name=f"risk_report_{date.today()}.csv",
                mime="text/csv"
            )

    # ════════════════════════════════════════════════════════════════════════
    # TAB 3 – Historical Analysis
    # ════════════════════════════════════════════════════════════════════════
    with tab3:
        st.subheader("📊 Historical No-Show Pattern Analysis")

        from utils.database import load_appointments
        all_appts = load_appointments()

        if all_appts.empty:
            st.info("No historical data available.")
            return

        # ── No-show rate by department ─────────────────────────────────────
        dept_ns = all_appts.groupby("department").apply(
            lambda x: pd.Series({
                "Total":     len(x),
                "No-Shows":  (x["status"]=="No-Show").sum(),
                "NS Rate":   round((x["status"]=="No-Show").mean() * 100, 1)
            })
        ).reset_index()

        fig_dept = px.bar(
            dept_ns.sort_values("NS Rate", ascending=False),
            x="department", y="NS Rate",
            color="NS Rate", color_continuous_scale="Reds",
            title="No-Show Rate by Department (%)",
            labels={"NS Rate":"No-Show Rate (%)","department":"Department"},
            text="NS Rate"
        )
        fig_dept.update_traces(texttemplate="%{text}%", textposition="outside")
        fig_dept.update_layout(coloraxis_showscale=False, height=350)
        st.plotly_chart(fig_dept, use_container_width=True)

        col_h1, col_h2 = st.columns(2)

        # ── No-show by lead days bucket ────────────────────────────────────
        with col_h1:
            bins_df = all_appts.copy()
            bins_df["lead_bucket"] = pd.cut(
                bins_df["booking_lead_days"], bins=[0,3,7,14,30],
                labels=["1-3 days","4-7 days","8-14 days","15-30 days"]
            )
            lead_ns = bins_df.groupby("lead_bucket", observed=False).apply(
                lambda x: round((x["status"]=="No-Show").mean()*100,1)
            ).reset_index()
            lead_ns.columns = ["Lead Time","NS Rate"]
            fig_lead = px.bar(
                lead_ns, x="Lead Time", y="NS Rate",
                color="NS Rate", color_continuous_scale="Oranges",
                title="No-Show Rate by Booking Lead Time (%)",
                text="NS Rate"
            )
            fig_lead.update_traces(texttemplate="%{text}%", textposition="outside")
            fig_lead.update_layout(coloraxis_showscale=False, height=300)
            st.plotly_chart(fig_lead, use_container_width=True)

        # ── No-show by distance ────────────────────────────────────────────
        with col_h2:
            dist_df = all_appts.copy()
            dist_df["dist_bucket"] = pd.cut(
                dist_df["distance_km"], bins=[0,10,20,35,60],
                labels=["<10 km","10-20 km","20-35 km",">35 km"]
            )
            dist_ns = dist_df.groupby("dist_bucket", observed=False).apply(
                lambda x: round((x["status"]=="No-Show").mean()*100,1)
            ).reset_index()
            dist_ns.columns = ["Distance","NS Rate"]
            fig_dist = px.bar(
                dist_ns, x="Distance", y="NS Rate",
                color="NS Rate", color_continuous_scale="Blues",
                title="No-Show Rate by Patient Distance (%)",
                text="NS Rate"
            )
            fig_dist.update_traces(texttemplate="%{text}%", textposition="outside")
            fig_dist.update_layout(coloraxis_showscale=False, height=300)
            st.plotly_chart(fig_dist, use_container_width=True)

        # ── Risk score vs actual outcome ───────────────────────────────────
        st.markdown("#### 🎯 Risk Score Distribution by Actual Outcome")
        outcome_df = all_appts[all_appts["status"].isin(["Completed","No-Show"])].copy()
        fig_box = px.box(
            outcome_df, x="status", y="no_show_risk",
            color="status",
            color_discrete_map={"Completed":"#22c55e","No-Show":"#ef4444"},
            title="Risk Score Distribution: Completed vs No-Show",
            labels={"status":"Outcome","no_show_risk":"Risk Score"}
        )
        fig_box.update_layout(height=350, showlegend=False)
        st.plotly_chart(fig_box, use_container_width=True)
