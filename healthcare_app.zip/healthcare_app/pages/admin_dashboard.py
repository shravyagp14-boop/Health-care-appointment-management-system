"""
Page 2 – Admin Dashboard
Full analytics, appointment management, doctor overview,
no-show risk management, and AI-powered insights.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta

from utils.database import (
    load_patients, load_doctors, load_appointments,
    update_appointment_status
)
from models.predictor import get_model_metrics
from utils.gemini_helper import analyze_admin_stats, chat_with_history


# ── Colour palette ────────────────────────────────────────────────────────────
PALETTE = {
    "primary": "#3b82d4", "success": "#22c55e",
    "warning": "#f59e0b", "danger":  "#ef4444",
    "muted":   "#94a3b8",
}


def _kpi_card(col, label, value, delta=None, icon=""):
    with col:
        if delta is not None:
            st.metric(f"{icon} {label}", value, delta)
        else:
            st.metric(f"{icon} {label}", value)


def show():
    st.title("🏥 Healthcare Admin Dashboard")
    st.markdown("Operational overview, analytics, and AI-driven insights.")

    api_key = st.session_state.get("gemini_api_key", "")

    # ── Load data ──────────────────────────────────────────────────────────
    appts   = load_appointments()
    patients = load_patients()
    doctors  = load_doctors()

    if appts.empty:
        st.warning("No appointment data found. Book some appointments first.")
        return

    appts["appointment_date"] = pd.to_datetime(appts["appointment_date"])
    today = pd.Timestamp(date.today())

    # ── Sidebar filters ────────────────────────────────────────────────────
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔎 Dashboard Filters")
    date_range = st.sidebar.date_input(
        "Date Range",
        value=(date.today() - timedelta(days=90), date.today()),
        key="admin_date_range"
    )
    dept_filter = st.sidebar.multiselect(
        "Department",
        sorted(appts["department"].unique()),
        default=sorted(appts["department"].unique())
    )
    status_filter = st.sidebar.multiselect(
        "Status",
        ["Scheduled","Completed","Cancelled","No-Show"],
        default=["Scheduled","Completed","Cancelled","No-Show"]
    )

    # Apply filters
    if len(date_range) == 2:
        start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
        filtered = appts[
            (appts["appointment_date"] >= start) &
            (appts["appointment_date"] <= end) &
            (appts["department"].isin(dept_filter)) &
            (appts["status"].isin(status_filter))
        ]
    else:
        filtered = appts[
            (appts["department"].isin(dept_filter)) &
            (appts["status"].isin(status_filter))
        ]

    total      = len(filtered)
    completed  = int((filtered["status"] == "Completed").sum())
    no_shows   = int((filtered["status"] == "No-Show").sum())
    cancelled  = int((filtered["status"] == "Cancelled").sum())
    scheduled  = int((filtered["status"] == "Scheduled").sum())
    ns_rate    = round(no_shows / total * 100, 1) if total else 0
    high_risk  = int((filtered["risk_label"] == "High").sum())
    top_dept   = filtered["department"].value_counts().idxmax() if total else "N/A"
    avg_lead   = filtered["booking_lead_days"].mean() if total else 0

    stats = {
        "total": total, "completed": completed, "no_shows": no_shows,
        "cancelled": cancelled, "scheduled": scheduled,
        "no_show_rate": ns_rate, "high_risk": high_risk,
        "top_dept": top_dept, "avg_lead": avg_lead
    }

    # ════════════════════════════════════════════════════════════════════════
    # TABS
    # ════════════════════════════════════════════════════════════════════════
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "📊 Overview", "📅 Appointments", "🔴 Risk Monitor",
        "👨‍⚕️ Doctors", "🤖 AI Insights", "⚙️ ML Model"
    ])

    # ════════════════════════════════════════════════════════════════════════
    # TAB 1 – Overview KPIs + Charts
    # ════════════════════════════════════════════════════════════════════════
    with tab1:
        st.subheader("Key Performance Indicators")
        k1, k2, k3, k4, k5, k6 = st.columns(6)
        _kpi_card(k1, "Total Appts",   total,     icon="📋")
        _kpi_card(k2, "Completed",     completed, icon="✅")
        _kpi_card(k3, "No-Shows",      no_shows,  icon="❌")
        _kpi_card(k4, "Cancelled",     cancelled, icon="🚫")
        _kpi_card(k5, "Scheduled",     scheduled, icon="📅")
        _kpi_card(k6, "No-Show Rate",  f"{ns_rate}%", icon="📉")

        st.markdown("---")
        row1_c1, row1_c2 = st.columns(2)

        # ── Appointments over time ─────────────────────────────────────────
        with row1_c1:
            st.markdown("#### 📈 Appointments Over Time")
            timeline = (
                filtered.groupby([filtered["appointment_date"].dt.to_period("W").astype(str), "status"])
                .size().reset_index(name="count")
            )
            fig = px.line(
                timeline, x="appointment_date", y="count", color="status",
                color_discrete_map={
                    "Completed": "#22c55e","No-Show": "#ef4444",
                    "Cancelled": "#f59e0b","Scheduled": "#3b82d4"
                },
                labels={"appointment_date":"Week","count":"Appointments","status":"Status"}
            )
            fig.update_layout(margin=dict(t=10,b=10), height=300)
            st.plotly_chart(fig, use_container_width=True)

        # ── Status distribution ────────────────────────────────────────────
        with row1_c2:
            st.markdown("#### 🍩 Status Distribution")
            status_counts = filtered["status"].value_counts().reset_index()
            status_counts.columns = ["Status","Count"]
            fig2 = px.pie(
                status_counts, values="Count", names="Status", hole=0.45,
                color="Status",
                color_discrete_map={
                    "Completed":"#22c55e","No-Show":"#ef4444",
                    "Cancelled":"#f59e0b","Scheduled":"#3b82d4"
                }
            )
            fig2.update_layout(margin=dict(t=10,b=10), height=300)
            st.plotly_chart(fig2, use_container_width=True)

        row2_c1, row2_c2 = st.columns(2)

        # ── Department load ────────────────────────────────────────────────
        with row2_c1:
            st.markdown("#### 🏥 Appointments by Department")
            dept_data = filtered["department"].value_counts().reset_index()
            dept_data.columns = ["Department","Count"]
            fig3 = px.bar(
                dept_data, x="Count", y="Department", orientation="h",
                color="Count", color_continuous_scale="Blues",
                labels={"Count":"Appointments"}
            )
            fig3.update_layout(margin=dict(t=10,b=10), height=320, coloraxis_showscale=False)
            st.plotly_chart(fig3, use_container_width=True)

        # ── Risk distribution ──────────────────────────────────────────────
        with row2_c2:
            st.markdown("#### 🎯 No-Show Risk Distribution")
            risk_data = filtered["risk_label"].value_counts().reset_index()
            risk_data.columns = ["Risk","Count"]
            fig4 = px.bar(
                risk_data, x="Risk", y="Count",
                color="Risk",
                color_discrete_map={"Low":"#22c55e","Medium":"#f59e0b","High":"#ef4444"},
                text="Count"
            )
            fig4.update_layout(margin=dict(t=10,b=10), height=320, showlegend=False)
            fig4.update_traces(textposition="outside")
            st.plotly_chart(fig4, use_container_width=True)

        # ── Monthly trend heatmap ──────────────────────────────────────────
        st.markdown("#### 📆 Monthly No-Show Heatmap")
        heatmap_data = filtered.copy()
        heatmap_data["month"] = heatmap_data["appointment_date"].dt.month_name()
        heatmap_data["dow"]   = heatmap_data["appointment_date"].dt.day_name()
        pivot = pd.crosstab(heatmap_data["dow"], heatmap_data["month"],
                            values=(heatmap_data["status"]=="No-Show").astype(int), aggfunc="sum")
        days_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        pivot = pivot.reindex([d for d in days_order if d in pivot.index])
        fig5 = go.Figure(data=go.Heatmap(
            z=pivot.values, x=pivot.columns.tolist(), y=pivot.index.tolist(),
            colorscale="Reds", showscale=True,
            hoverongaps=False
        ))
        fig5.update_layout(margin=dict(t=10,b=10), height=280)
        st.plotly_chart(fig5, use_container_width=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 2 – Appointments Table
    # ════════════════════════════════════════════════════════════════════════
    with tab2:
        st.subheader("All Appointments")

        search = st.text_input("🔍 Search by patient name or appointment ID")
        if search:
            mask = (
                filtered["patient_name"].str.contains(search, case=False, na=False) |
                filtered["appointment_id"].str.contains(search, case=False, na=False)
            )
            filtered_view = filtered[mask]
        else:
            filtered_view = filtered

        display_cols = ["appointment_id","patient_name","doctor_name","department",
                        "appointment_date","appointment_time","reason","status",
                        "risk_label","no_show_risk","previous_no_shows","booking_lead_days"]
        df_display = filtered_view[display_cols].copy()
        df_display["appointment_date"] = df_display["appointment_date"].dt.strftime("%d %b %Y")
        df_display["no_show_risk"] = df_display["no_show_risk"].round(1)
        df_display.columns = ["ID","Patient","Doctor","Dept","Date","Time","Reason",
                               "Status","Risk","Score","Prev NS","Lead Days"]

        def _hl_risk(val):
            c = {"High":"#ffd5d5","Medium":"#fff5cc","Low":"#d5f5d5"}
            return f"background-color: {c.get(val,'')}"

        def _hl_status(val):
            c = {"Completed":"#d4edda","No-Show":"#f8d7da",
                 "Cancelled":"#fff3cd","Scheduled":"#d1ecf1"}
            return f"background-color: {c.get(val,'')}"

        st.dataframe(
            df_display.style
                .applymap(_hl_risk, subset=["Risk"])
                .applymap(_hl_status, subset=["Status"]),
            use_container_width=True, hide_index=True, height=420
        )

        # ── Update status ──────────────────────────────────────────────────
        st.markdown("---")
        st.markdown("#### ✏️ Update Appointment Status")
        uc1, uc2, uc3 = st.columns([2,2,1])
        appt_ids_list = filtered_view["appointment_id"].tolist()
        sel_appt = uc1.selectbox("Select Appointment ID", appt_ids_list if appt_ids_list else ["None"])
        new_status = uc2.selectbox("New Status", ["Scheduled","Completed","Cancelled","No-Show"])
        if uc3.button("Update", use_container_width=True):
            if sel_appt != "None":
                update_appointment_status(sel_appt, new_status)
                st.success(f"✅ Appointment {sel_appt} updated to **{new_status}**")
                st.rerun()

        # ── CSV Export ─────────────────────────────────────────────────────
        st.download_button(
            "⬇️ Export to CSV",
            data=df_display.to_csv(index=False).encode(),
            file_name=f"appointments_{date.today()}.csv",
            mime="text/csv"
        )

    # ════════════════════════════════════════════════════════════════════════
    # TAB 3 – Risk Monitor
    # ════════════════════════════════════════════════════════════════════════
    with tab3:
        st.subheader("🔴 No-Show Risk Monitor")
        st.markdown("Focus on high-risk upcoming appointments that need proactive intervention.")

        upcoming = filtered[
            (filtered["status"] == "Scheduled") &
            (filtered["appointment_date"] >= today)
        ].sort_values("no_show_risk", ascending=False)

        if upcoming.empty:
            st.info("No upcoming scheduled appointments in the selected filters.")
        else:
            risk_counts = upcoming["risk_label"].value_counts()
            r1, r2, r3 = st.columns(3)
            r1.metric("🔴 High Risk",   int(risk_counts.get("High",0)))
            r2.metric("🟡 Medium Risk", int(risk_counts.get("Medium",0)))
            r3.metric("🟢 Low Risk",    int(risk_counts.get("Low",0)))

            st.markdown("---")
            for rl, emoji, color in [("High","🔴","#ffd5d5"),("Medium","🟡","#fffacc"),("Low","🟢","#d5f5d5")]:
                group = upcoming[upcoming["risk_label"] == rl]
                if group.empty:
                    continue
                st.markdown(f"#### {emoji} {rl} Risk Appointments ({len(group)})")
                gcols = ["appointment_id","patient_name","doctor_name","department",
                         "appointment_date","appointment_time","no_show_risk",
                         "previous_no_shows","distance_km","booking_lead_days","sms_reminder_sent"]
                gdf   = group[gcols].copy()
                gdf["appointment_date"] = gdf["appointment_date"].dt.strftime("%d %b %Y")
                gdf["no_show_risk"]     = gdf["no_show_risk"].round(1)
                gdf.columns = ["ID","Patient","Doctor","Dept","Date","Time",
                                "Risk Score","Prev NS","Distance(km)","Lead Days","SMS Sent"]
                st.dataframe(gdf.style.background_gradient(subset=["Risk Score"], cmap="Reds"),
                             use_container_width=True, hide_index=True)

            # ── Risk scatter ───────────────────────────────────────────────
            st.markdown("---")
            st.markdown("#### 🎯 Risk Score vs Lead Days vs Distance")
            scatter_fig = px.scatter(
                upcoming, x="booking_lead_days", y="no_show_risk",
                size="distance_km", color="risk_label",
                hover_data=["patient_name","doctor_name","appointment_date"],
                color_discrete_map={"Low":"#22c55e","Medium":"#f59e0b","High":"#ef4444"},
                labels={"booking_lead_days":"Booking Lead Days",
                        "no_show_risk":"No-Show Risk Score"},
                size_max=30
            )
            scatter_fig.update_layout(height=400)
            st.plotly_chart(scatter_fig, use_container_width=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 4 – Doctors
    # ════════════════════════════════════════════════════════════════════════
    with tab4:
        st.subheader("👨‍⚕️ Doctor Performance & Load")

        # appointments per doctor
        doc_stats = filtered.groupby("doctor_name").agg(
            Total       = ("appointment_id","count"),
            Completed   = ("status", lambda x: (x=="Completed").sum()),
            No_Shows    = ("status", lambda x: (x=="No-Show").sum()),
            Avg_Risk    = ("no_show_risk","mean"),
        ).reset_index()
        doc_stats["No_Show_Rate"] = (doc_stats["No_Shows"] / doc_stats["Total"] * 100).round(1)
        doc_stats["Avg_Risk"]     = doc_stats["Avg_Risk"].round(1)
        doc_stats.columns = ["Doctor","Total","Completed","No-Shows","Avg Risk","NS Rate(%)"]

        st.dataframe(
            doc_stats.style.background_gradient(subset=["NS Rate(%)"], cmap="Reds"),
            use_container_width=True, hide_index=True
        )

        # Doctor load chart
        fig_doc = px.bar(
            doc_stats.sort_values("Total", ascending=False),
            x="Doctor", y=["Completed","No-Shows"],
            barmode="stack",
            color_discrete_map={"Completed":"#22c55e","No-Shows":"#ef4444"},
            title="Doctor Appointment Load"
        )
        fig_doc.update_layout(height=350, xaxis_tickangle=-30)
        st.plotly_chart(fig_doc, use_container_width=True)

        st.markdown("---")
        st.subheader("Doctor Directory")
        doc_dir_cols = ["doctor_id","name","department","qualification","experience_years","available_days"]
        st.dataframe(doctors[doc_dir_cols], use_container_width=True, hide_index=True)

    # ════════════════════════════════════════════════════════════════════════
    # TAB 5 – AI Insights
    # ════════════════════════════════════════════════════════════════════════
    with tab5:
        st.subheader("🤖 AI-Powered Insights (Gemini 2.5 Flash)")

        if not api_key:
            st.warning("⚠️ Please enter your Gemini API key in the sidebar.")
        else:
            col_a, col_b = st.columns([1,1])

            with col_a:
                st.markdown("#### 📊 Dashboard Analytics Interpretation")
                if st.button("🤖 Analyze Current Stats", use_container_width=True):
                    with st.spinner("Gemini 2.5 Flash is analyzing…"):
                        insight = analyze_admin_stats(api_key, stats)
                    st.markdown(insight)

            with col_b:
                st.markdown("#### 💬 Admin AI Chat")
                if "admin_chat_history" not in st.session_state:
                    st.session_state.admin_chat_history = []

                for msg in st.session_state.admin_chat_history[-6:]:
                    icon = "🧑‍💼" if msg["role"] == "user" else "🤖"
                    with st.chat_message(msg["role"]):
                        st.markdown(f"{icon} {msg['content']}")

                admin_input = st.chat_input("Ask about clinic operations…", key="admin_chat_input")
                if admin_input:
                    st.session_state.admin_chat_history.append(
                        {"role":"user","content":admin_input}
                    )
                    context = (
                        f"Current clinic stats: Total={total}, Completed={completed}, "
                        f"No-Shows={no_shows}, No-Show Rate={ns_rate}%, "
                        f"High-Risk={high_risk}, Top Dept={top_dept}."
                    )
                    with st.spinner("Thinking…"):
                        reply = chat_with_history(
                            api_key,
                            st.session_state.admin_chat_history[:-1],
                            f"[Context: {context}]\n{admin_input}"
                        )
                    st.session_state.admin_chat_history.append(
                        {"role":"model","content":reply}
                    )
                    st.rerun()

                if st.button("🗑️ Clear Chat", key="clear_admin_chat"):
                    st.session_state.admin_chat_history = []
                    st.rerun()

    # ════════════════════════════════════════════════════════════════════════
    # TAB 6 – ML Model Metrics
    # ════════════════════════════════════════════════════════════════════════
    with tab6:
        st.subheader("⚙️ ML No-Show Predictor — Model Info")

        st.markdown("""
        ### Model Architecture
        The no-show risk predictor uses a **Gradient Boosting Classifier** with
        **Isotonic Calibration** to output calibrated probabilities.

        **Features used:**
        | Feature | Description |
        |---------|-------------|
        | `age` | Patient age |
        | `previous_no_shows` | Historical missed appointments |
        | `booking_lead_days` | Days between booking and appointment |
        | `distance_km` | Distance from clinic |
        | `sms_reminder_sent` | Whether SMS reminder was sent |
        | `is_chronic` | Has chronic condition (0/1) |
        | `hour_of_day` | Appointment hour |
        | `day_of_week` | Day of week (0=Mon) |
        | `age_bucket` | Age group category |
        | `risk_interaction` | `prev_no_shows × lead_days` |

        **Risk Thresholds:**
        - 🟢 **Low Risk**: Score 0–34
        - 🟡 **Medium Risk**: Score 35–64
        - 🔴 **High Risk**: Score 65–100
        """)

        col_m1, col_m2 = st.columns([1,2])
        with col_m1:
            if st.button("📊 Compute Model Metrics", use_container_width=True):
                with st.spinner("Evaluating model on held-out test set…"):
                    metrics = get_model_metrics()
                st.success("Model evaluation complete!")
                st.metric("Accuracy",   f"{metrics['accuracy']}%")
                st.metric("ROC-AUC",    f"{metrics['roc_auc']}%")
                st.metric("Precision",  f"{metrics['precision']}%")
                st.metric("Recall",     f"{metrics['recall']}%")

        with col_m2:
            st.markdown("#### Feature Importance (Conceptual)")
            feature_importance = {
                "Previous No-Shows": 32,
                "Booking Lead Days": 18,
                "Distance (km)": 14,
                "Age": 11,
                "SMS Reminder": 10,
                "Risk Interaction": 7,
                "Hour of Day": 4,
                "Day of Week": 3,
                "Is Chronic": 1,
            }
            fi_df = pd.DataFrame(
                list(feature_importance.items()), columns=["Feature","Importance"]
            ).sort_values("Importance")
            fig_fi = px.bar(
                fi_df, x="Importance", y="Feature", orientation="h",
                color="Importance", color_continuous_scale="Blues",
                title="Feature Importance (%)"
            )
            fig_fi.update_layout(height=350, coloraxis_showscale=False)
            st.plotly_chart(fig_fi, use_container_width=True)
