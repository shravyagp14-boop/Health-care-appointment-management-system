"""
Page 1 – Patient Booking Module
Streamlit page for patients to register, book appointments, and view history.
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date, timedelta

from utils.database import (
    load_patients, load_doctors, load_appointments,
    save_patient, save_appointment,
    next_patient_id, next_appointment_id,
    get_patient_appointments, get_patient_no_show_count
)
from models.predictor import predict_no_show_risk
from utils.gemini_helper import explain_risk, chat_with_history


# ── Risk colour helper ────────────────────────────────────────────────────────
def _risk_badge(label):
    colors = {"Low": "🟢", "Medium": "🟡", "High": "🔴"}
    return colors.get(label, "⚪")


def show():
    st.title("🏥 Patient Appointment Booking")
    st.markdown("Book, manage, and track your healthcare appointments.")

    api_key = st.session_state.get("gemini_api_key", "")

    tab1, tab2, tab3 = st.tabs(["📅 Book Appointment", "👤 My Appointments", "🤖 AI Health Assistant"])

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 1 – Book Appointment
    # ═══════════════════════════════════════════════════════════════════════
    with tab1:
        st.subheader("Book a New Appointment")

        col_reg, col_book = st.columns([1, 2], gap="large")

        # ── Patient Registration / Lookup ──────────────────────────────────
        with col_reg:
            st.markdown("#### 👤 Patient Details")
            mode = st.radio("Are you a", ["New Patient", "Existing Patient"], horizontal=True)

            patients_df = load_patients()

            if mode == "Existing Patient":
                if patients_df.empty:
                    st.warning("No patients registered yet.")
                    selected_patient = None
                else:
                    patient_names = patients_df["name"].tolist()
                    chosen_name   = st.selectbox("Select your name", patient_names)
                    selected_patient = patients_df[patients_df["name"] == chosen_name].iloc[0].to_dict()
                    st.info(
                        f"**ID:** {selected_patient['patient_id']}  \n"
                        f"**Age:** {selected_patient['age']}  \n"
                        f"**Blood Group:** {selected_patient['blood_group']}  \n"
                        f"**Conditions:** {selected_patient.get('chronic_conditions','None')}"
                    )
            else:
                selected_patient = None
                with st.form("register_form"):
                    p_name  = st.text_input("Full Name *")
                    p_col1, p_col2 = st.columns(2)
                    p_age   = p_col1.number_input("Age *", min_value=1, max_value=120, value=30)
                    p_gender = p_col2.selectbox("Gender", ["Male", "Female", "Other"])
                    p_phone = st.text_input("Phone *")
                    p_email = st.text_input("Email")
                    p_blood = st.selectbox("Blood Group", ["A+","A-","B+","B-","O+","O-","AB+","AB-"])
                    p_cond  = st.text_input("Chronic Conditions (comma-separated or 'None')", value="None")
                    reg_submit = st.form_submit_button("✅ Register & Continue", use_container_width=True)

                if reg_submit:
                    if not p_name or not p_phone:
                        st.error("Name and Phone are required.")
                    else:
                        new_pid = next_patient_id()
                        new_patient = {
                            "patient_id":          new_pid,
                            "name":                p_name,
                            "age":                 p_age,
                            "gender":              p_gender,
                            "phone":               p_phone,
                            "email":               p_email,
                            "blood_group":         p_blood,
                            "chronic_conditions":  p_cond,
                            "registration_date":   date.today().isoformat(),
                        }
                        save_patient(new_patient)
                        st.success(f"✅ Registered! Your Patient ID: **{new_pid}**")
                        selected_patient = new_patient
                        st.session_state["registered_patient"] = new_patient
                        st.rerun()

        # ── Appointment Form ───────────────────────────────────────────────
        with col_book:
            # Retrieve patient from form or session
            if selected_patient is None:
                selected_patient = st.session_state.get("registered_patient")

            if selected_patient is None and mode == "New Patient":
                st.info("👈 Register yourself first to book an appointment.")
            else:
                if selected_patient is None and mode == "Existing Patient":
                    pass
                else:
                    st.markdown(f"#### 📅 Booking for **{selected_patient['name']}**")
                    doctors_df = load_doctors()
                    departments = sorted(doctors_df["department"].unique().tolist())

                    with st.form("booking_form"):
                        dept     = st.selectbox("Select Department", departments)
                        dept_docs = doctors_df[doctors_df["department"] == dept]["name"].tolist()
                        doctor   = st.selectbox("Select Doctor", dept_docs)
                        reason   = st.selectbox("Reason for Visit",
                                                ["Routine Checkup","Follow-up","Consultation",
                                                 "Emergency","Lab Review","Vaccination","Other"])
                        appt_date = st.date_input("Appointment Date",
                                                  min_value=date.today(),
                                                  max_value=date.today() + timedelta(days=90))
                        time_slots = ["08:00","09:00","10:00","11:00","12:00",
                                      "14:00","15:00","16:00","17:00"]
                        appt_time = st.selectbox("Preferred Time Slot", time_slots)
                        distance  = st.slider("Your approximate distance from clinic (km)", 1, 60, 10)
                        sms       = st.checkbox("Send SMS Reminder?", value=True)

                        book_btn  = st.form_submit_button("🗓️ Book Appointment", use_container_width=True)

                    if book_btn:
                        lead_days  = (appt_date - date.today()).days
                        prev_ns    = get_patient_no_show_count(selected_patient["patient_id"])
                        doc_row    = doctors_df[doctors_df["name"] == doctor].iloc[0]
                        risk_result = predict_no_show_risk(
                            age              = int(selected_patient["age"]),
                            previous_no_shows= prev_ns,
                            booking_lead_days= lead_days,
                            distance_km      = distance,
                            sms_reminder_sent= sms,
                            chronic_conditions= str(selected_patient.get("chronic_conditions","None")),
                            appointment_time = appt_time,
                            appointment_date = appt_date.isoformat(),
                        )

                        appt_id = next_appointment_id()
                        appt = {
                            "appointment_id":   appt_id,
                            "patient_id":       selected_patient["patient_id"],
                            "patient_name":     selected_patient["name"],
                            "doctor_id":        doc_row["doctor_id"],
                            "doctor_name":      doctor,
                            "department":       dept,
                            "appointment_date": appt_date.isoformat(),
                            "appointment_time": appt_time,
                            "reason":           reason,
                            "status":           "Scheduled",
                            "no_show_risk":     risk_result["risk_score"],
                            "risk_label":       risk_result["risk_label"],
                            "previous_no_shows":prev_ns,
                            "distance_km":      distance,
                            "sms_reminder_sent":sms,
                            "booking_lead_days":lead_days,
                            "created_at":       datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        }
                        save_appointment(appt)

                        # ── Confirmation card ──────────────────────────────
                        st.success("✅ Appointment booked successfully!")
                        st.markdown("---")
                        c1, c2, c3 = st.columns(3)
                        c1.metric("Appointment ID", appt_id)
                        c2.metric("Date & Time", f"{appt_date.strftime('%d %b %Y')} {appt_time}")
                        c3.metric("Doctor", doctor.split(". ")[-1])

                        # ── Risk display ───────────────────────────────────
                        rl = risk_result["risk_label"]
                        color_map = {"Low": "success", "Medium": "warning", "High": "error"}
                        badge     = {"Low": "🟢", "Medium": "🟡", "High": "🔴"}
                        st.markdown(f"#### {badge[rl]} No-Show Risk Assessment")
                        st.markdown(
                            f"**Risk Score:** {risk_result['risk_score']:.1f}/100 &nbsp;|&nbsp; "
                            f"**Level:** {rl}"
                        )
                        with st.expander("📋 Risk Factors & Recommendation"):
                            for f in risk_result["risk_factors"]:
                                st.markdown(f"- {f}")
                            st.markdown(f"**Recommendation:** {risk_result['recommendation']}")

                        # ── Gemini explanation ─────────────────────────────
                        if api_key:
                            with st.spinner("🤖 Generating AI risk explanation…"):
                                explanation = explain_risk(
                                    api_key,
                                    selected_patient["name"],
                                    risk_result["risk_score"],
                                    risk_result["risk_label"],
                                    risk_result["risk_factors"],
                                    risk_result["recommendation"],
                                )
                            with st.expander("🤖 AI Powered Risk Insight (Gemini 2.5 Flash)"):
                                st.markdown(explanation)

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 2 – My Appointments
    # ═══════════════════════════════════════════════════════════════════════
    with tab2:
        st.subheader("My Appointment History")
        patients_df = load_patients()

        if patients_df.empty:
            st.info("No patients registered yet.")
        else:
            sel_name = st.selectbox("Select Patient", patients_df["name"].tolist(), key="hist_select")
            patient  = patients_df[patients_df["name"] == sel_name].iloc[0]
            appts    = get_patient_appointments(patient["patient_id"])

            if appts.empty:
                st.info("No appointments found for this patient.")
            else:
                # Summary metrics
                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Total Appointments", len(appts))
                m2.metric("Completed",     int((appts["status"] == "Completed").sum()))
                m3.metric("No-Shows",      int((appts["status"] == "No-Show").sum()))
                m4.metric("Upcoming",      int((appts["status"] == "Scheduled").sum()))

                st.markdown("---")
                # Status filter
                status_filter = st.multiselect(
                    "Filter by Status",
                    ["Scheduled","Completed","Cancelled","No-Show"],
                    default=["Scheduled","Completed","Cancelled","No-Show"]
                )
                filtered = appts[appts["status"].isin(status_filter)]

                # Display table
                display_cols = ["appointment_id","appointment_date","appointment_time",
                                "doctor_name","department","reason","status","risk_label","no_show_risk"]
                display_df = filtered[display_cols].copy()
                display_df["appointment_date"] = pd.to_datetime(display_df["appointment_date"]).dt.strftime("%d %b %Y")
                display_df.columns = ["ID","Date","Time","Doctor","Dept","Reason","Status","Risk","Score"]

                def _color_status(val):
                    c = {"Completed":"#d4edda","No-Show":"#f8d7da",
                         "Cancelled":"#fff3cd","Scheduled":"#d1ecf1"}
                    return f"background-color: {c.get(val,'')}"

                st.dataframe(
                    display_df.style.applymap(_color_status, subset=["Status"]),
                    use_container_width=True, hide_index=True
                )

                # Gemini patient summary
                if api_key:
                    if st.button("🤖 Generate AI Patient Summary", key="pt_summary_btn"):
                        with st.spinner("Generating summary with Gemini 2.5 Flash…"):
                            from utils.gemini_helper import generate_patient_summary
                            appts_list = filtered[display_cols].rename(
                                columns={"appointment_date":"appointment_date",
                                         "department":"department","status":"status",
                                         "risk_label":"risk_label"}).to_dict("records")
                            summary = generate_patient_summary(api_key, patient.to_dict(), appts_list)
                        st.markdown("#### 🤖 AI Patient Summary")
                        st.markdown(summary)

    # ═══════════════════════════════════════════════════════════════════════
    # TAB 3 – AI Health Chat
    # ═══════════════════════════════════════════════════════════════════════
    with tab3:
        st.subheader("🤖 AI Health Assistant (Gemini 2.5 Flash)")

        if not api_key:
            st.warning("⚠️ Please enter your Gemini API key in the sidebar to use the AI assistant.")
        else:
            st.markdown(
                "Ask anything about appointments, health tips, or understanding your risk factors. "
                "This assistant is powered by **Gemini 2.5 Flash**."
            )

            # Chat history
            if "patient_chat_history" not in st.session_state:
                st.session_state.patient_chat_history = []

            # Display messages
            for msg in st.session_state.patient_chat_history:
                role_icon = "🧑‍💻" if msg["role"] == "user" else "🤖"
                with st.chat_message(msg["role"]):
                    st.markdown(f"{role_icon} {msg['content']}")

            # Input
            user_input = st.chat_input("Type your question here…")
            if user_input:
                st.session_state.patient_chat_history.append(
                    {"role": "user", "content": user_input}
                )
                with st.chat_message("user"):
                    st.markdown(f"🧑‍💻 {user_input}")

                with st.spinner("HealthBot is thinking…"):
                    history_for_api = st.session_state.patient_chat_history[:-1]
                    reply = chat_with_history(api_key, history_for_api, user_input)

                st.session_state.patient_chat_history.append(
                    {"role": "model", "content": reply}
                )
                with st.chat_message("assistant"):
                    st.markdown(f"🤖 {reply}")

            if st.button("🗑️ Clear Chat", key="clear_pt_chat"):
                st.session_state.patient_chat_history = []
                st.rerun()
