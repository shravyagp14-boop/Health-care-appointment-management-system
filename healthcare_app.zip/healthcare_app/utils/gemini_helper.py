"""
Gemini 2.5 Flash AI Assistant for the Healthcare App.
Provides:
  - Medical Q&A assistant
  - Appointment summary & insights
  - Patient risk narrative
  - Admin analytics interpretation
"""

import os
import streamlit as st

try:
    import google.generativeai as genai
    GENAI_AVAILABLE = True
except ImportError:
    GENAI_AVAILABLE = False


SYSTEM_PROMPT = """You are HealthBot, an AI assistant embedded in a healthcare appointment management system.
You help:
1. Patients understand their appointments, health tips, and no-show risk.
2. Admins interpret analytics, patient trends, and scheduling efficiency.
3. Doctors understand patient risk factors before appointments.

Rules:
- Always recommend consulting a licensed doctor for medical decisions.
- Be empathetic, clear, and professional.
- Keep responses concise (under 250 words unless asked for detail).
- Use bullet points for lists.
- Never fabricate patient data — only use context provided.
- If a question is outside healthcare/appointments, politely decline.
"""


def configure_gemini(api_key: str):
    """Configure the Gemini client with the user's API key."""
    if not GENAI_AVAILABLE:
        return False
    try:
        genai.configure(api_key=api_key)
        return True
    except Exception:
        return False


def get_gemini_model(api_key: str):
    """Return a configured Gemini 2.5 Flash model instance."""
    if not GENAI_AVAILABLE:
        return None
    configure_gemini(api_key)
    return genai.GenerativeModel(
        model_name="gemini-2.5-flash",
        system_instruction=SYSTEM_PROMPT,
        generation_config=genai.GenerationConfig(
            temperature=0.4,
            max_output_tokens=1024,
        ),
    )


def ask_gemini(api_key: str, user_message: str, context: str = "") -> str:
    """Send a single question to Gemini and return the text response."""
    if not api_key or not GENAI_AVAILABLE:
        return "⚠️ Gemini API key not configured. Please enter your API key in the sidebar."
    try:
        model = get_gemini_model(api_key)
        full_prompt = f"{context}\n\n{user_message}" if context else user_message
        response = model.generate_content(full_prompt)
        return response.text
    except Exception as e:
        return f"⚠️ Gemini error: {str(e)}"


def explain_risk(api_key: str, patient_name: str, risk_score: float,
                 risk_label: str, risk_factors: list, recommendation: str) -> str:
    """Generate a natural-language explanation of a patient's no-show risk."""
    context = f"""
Patient: {patient_name}
No-Show Risk Score: {risk_score}/100 ({risk_label})
Risk Factors: {', '.join(risk_factors)}
System Recommendation: {recommendation}
"""
    prompt = (
        "Based on the above patient no-show risk assessment, provide:\n"
        "1. A brief, empathetic explanation of why this patient might miss their appointment.\n"
        "2. Three specific actionable interventions the clinic can take.\n"
        "3. A short message the receptionist could say when calling the patient."
    )
    return ask_gemini(api_key, prompt, context)


def analyze_admin_stats(api_key: str, stats: dict) -> str:
    """Generate narrative insights from dashboard statistics."""
    context = f"""
Current Appointment Statistics:
- Total Appointments: {stats.get('total', 0)}
- Completed: {stats.get('completed', 0)}
- No-Shows: {stats.get('no_shows', 0)}
- Cancelled: {stats.get('cancelled', 0)}
- Scheduled (upcoming): {stats.get('scheduled', 0)}
- No-Show Rate: {stats.get('no_show_rate', 0):.1f}%
- High Risk Appointments: {stats.get('high_risk', 0)}
- Top Department: {stats.get('top_dept', 'N/A')}
- Average Lead Time: {stats.get('avg_lead', 0):.1f} days
"""
    prompt = (
        "Analyze these clinic statistics and provide:\n"
        "1. Key insights about appointment trends.\n"
        "2. Main concerns that need attention.\n"
        "3. Three data-driven recommendations to improve appointment attendance.\n"
        "Keep the tone professional and actionable."
    )
    return ask_gemini(api_key, prompt, context)


def generate_patient_summary(api_key: str, patient_data: dict, appointments: list) -> str:
    """Generate a patient health summary for the admin."""
    appt_str = "\n".join([
        f"- {a['appointment_date']} | {a['department']} | {a['status']} | Risk: {a['risk_label']}"
        for a in appointments[:10]
    ])
    context = f"""
Patient Profile:
- Name: {patient_data.get('name')}
- Age: {patient_data.get('age')}
- Gender: {patient_data.get('gender')}
- Chronic Conditions: {patient_data.get('chronic_conditions', 'None')}
- Blood Group: {patient_data.get('blood_group')}

Recent Appointments:
{appt_str}
"""
    prompt = (
        "Provide a concise clinical summary for this patient including:\n"
        "1. Patient profile overview.\n"
        "2. Appointment attendance pattern.\n"
        "3. Any health-related concerns based on chronic conditions.\n"
        "4. Suggestions for follow-up care."
    )
    return ask_gemini(api_key, prompt, context)


def chat_with_history(api_key: str, chat_history: list, new_message: str) -> str:
    """Multi-turn chat using Gemini chat session."""
    if not api_key or not GENAI_AVAILABLE:
        return "⚠️ Gemini API key not configured. Please enter your API key in the sidebar."
    try:
        model = get_gemini_model(api_key)
        # Convert history to Gemini format
        formatted_history = []
        for msg in chat_history:
            formatted_history.append({
                "role": msg["role"],
                "parts": [msg["content"]]
            })
        chat = model.start_chat(history=formatted_history)
        response = chat.send_message(new_message)
        return response.text
    except Exception as e:
        return f"⚠️ Gemini error: {str(e)}"
