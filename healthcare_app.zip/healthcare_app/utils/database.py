"""
Lightweight JSON/CSV-based persistence layer (no external DB required).
All data is stored under healthcare_app/data/ as CSV files so the app
is fully self-contained and Streamlit-deployable.
"""

import os
import json
import pandas as pd
from datetime import datetime

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)

# ── File paths ──────────────────────────────────────────────────────────────
PATIENTS_FILE    = os.path.join(DATA_DIR, "patients.csv")
APPOINTMENTS_FILE = os.path.join(DATA_DIR, "appointments.csv")
DOCTORS_FILE     = os.path.join(DATA_DIR, "doctors.csv")

# ── Column schemas ───────────────────────────────────────────────────────────
PATIENT_COLS = [
    "patient_id", "name", "age", "gender", "phone", "email",
    "blood_group", "chronic_conditions", "registration_date"
]

APPOINTMENT_COLS = [
    "appointment_id", "patient_id", "patient_name", "doctor_id",
    "doctor_name", "department", "appointment_date", "appointment_time",
    "reason", "status",           # Scheduled / Completed / Cancelled / No-Show
    "no_show_risk",               # 0-100 float from ML model
    "risk_label",                 # Low / Medium / High
    "previous_no_shows",
    "distance_km",
    "sms_reminder_sent",
    "booking_lead_days",
    "created_at"
]

DOCTOR_COLS = [
    "doctor_id", "name", "department", "qualification",
    "experience_years", "available_days", "available_slots"
]


# ── Seed helpers ─────────────────────────────────────────────────────────────
def _seed_doctors():
    doctors = [
        {"doctor_id": "D001", "name": "Dr. Ananya Sharma",   "department": "Cardiology",
         "qualification": "MD, DM Cardiology", "experience_years": 15,
         "available_days": "Mon,Wed,Fri",
         "available_slots": "09:00,10:00,11:00,14:00,15:00,16:00"},
        {"doctor_id": "D002", "name": "Dr. Rajesh Kumar",    "department": "Neurology",
         "qualification": "MD, DM Neurology",  "experience_years": 12,
         "available_days": "Tue,Thu,Sat",
         "available_slots": "09:00,10:00,11:00,14:00,15:00"},
        {"doctor_id": "D003", "name": "Dr. Priya Nair",      "department": "Orthopedics",
         "qualification": "MS Orthopedics",    "experience_years": 10,
         "available_days": "Mon,Tue,Thu,Fri",
         "available_slots": "10:00,11:00,12:00,15:00,16:00,17:00"},
        {"doctor_id": "D004", "name": "Dr. Suresh Menon",    "department": "General Medicine",
         "qualification": "MBBS, MD",          "experience_years": 8,
         "available_days": "Mon,Tue,Wed,Thu,Fri",
         "available_slots": "08:00,09:00,10:00,11:00,14:00,15:00,16:00"},
        {"doctor_id": "D005", "name": "Dr. Kavitha Iyer",    "department": "Dermatology",
         "qualification": "MD Dermatology",    "experience_years": 7,
         "available_days": "Tue,Wed,Fri",
         "available_slots": "10:00,11:00,14:00,15:00,16:00"},
        {"doctor_id": "D006", "name": "Dr. Arun Patel",      "department": "Pediatrics",
         "qualification": "MD Pediatrics",     "experience_years": 11,
         "available_days": "Mon,Wed,Thu,Sat",
         "available_slots": "09:00,10:00,11:00,14:00,15:00"},
        {"doctor_id": "D007", "name": "Dr. Meera Reddy",     "department": "Gynecology",
         "qualification": "MS Gynecology",     "experience_years": 9,
         "available_days": "Mon,Tue,Thu,Fri",
         "available_slots": "09:00,10:00,11:00,14:00,15:00,16:00"},
        {"doctor_id": "D008", "name": "Dr. Vikram Singh",    "department": "Psychiatry",
         "qualification": "MD Psychiatry",     "experience_years": 13,
         "available_days": "Tue,Wed,Fri",
         "available_slots": "10:00,11:00,14:00,15:00"},
    ]
    pd.DataFrame(doctors, columns=DOCTOR_COLS).to_csv(DOCTORS_FILE, index=False)


def _seed_patients_and_appointments():
    import random, numpy as np
    from datetime import timedelta
    rng = random.Random(42)
    np.random.seed(42)

    names = [
        "Aarav Mehta","Diya Kapoor","Rohan Verma","Sneha Nair","Arjun Das",
        "Pooja Sharma","Karan Singh","Anita Gupta","Manish Tiwari","Ritu Jain",
        "Vikram Rao","Sonal Mishra","Prateek Joshi","Lavanya Kumar","Deepak Patel",
        "Neha Iyer","Siddharth Reddy","Pallavi Desai","Rahul Bose","Swati Pillai",
        "Amit Chaudhary","Shweta Pandey","Nikhil Saxena","Priya Malhotra","Gaurav Shah",
        "Rupali Shetty","Aditya Naik","Shruti Varma","Prakash Hegde","Meena Choudhary"
    ]
    blood_groups = ["A+","A-","B+","B-","O+","O-","AB+","AB-"]
    genders      = ["Male","Female","Other"]
    conditions   = ["None","Hypertension","Diabetes","Asthma","Heart Disease",
                    "Hypertension,Diabetes","Arthritis","None","None","None"]

    patients, appointments = [], []
    appt_id = 1
    for i, name in enumerate(names):
        pid  = f"P{i+1:03d}"
        age  = rng.randint(18, 75)
        prev_ns = rng.choices([0,1,2,3,4,5], weights=[40,25,15,10,6,4])[0]
        patients.append({
            "patient_id": pid, "name": name, "age": age,
            "gender": rng.choice(genders),
            "phone": f"9{rng.randint(100000000,999999999)}",
            "email": f"{name.lower().replace(' ','.')}{rng.randint(1,99)}@email.com",
            "blood_group": rng.choice(blood_groups),
            "chronic_conditions": rng.choice(conditions),
            "registration_date": (datetime(2023,1,1) + timedelta(days=rng.randint(0,365))).strftime("%Y-%m-%d"),
        })
        # 3-8 historical appointments per patient
        for _ in range(rng.randint(3, 8)):
            appt_date = datetime(2024,1,1) + timedelta(days=rng.randint(0,300))
            lead      = rng.randint(1, 30)
            dist      = round(rng.uniform(1, 50), 1)
            sms       = rng.choice([True, False])
            risk_score = _compute_risk(age, prev_ns, lead, dist, sms)
            risk_label = "High" if risk_score >= 65 else ("Medium" if risk_score >= 35 else "Low")
            statuses   = ["Completed","Completed","Completed","No-Show","Cancelled"]
            if prev_ns >= 3:
                statuses = ["Completed","No-Show","No-Show","Cancelled"]
            doc = rng.choice(["D001","D002","D003","D004","D005","D006","D007","D008"])
            appointments.append({
                "appointment_id": f"A{appt_id:04d}",
                "patient_id": pid,
                "patient_name": name,
                "doctor_id": doc,
                "doctor_name": _doctor_name(doc),
                "department": _doctor_dept(doc),
                "appointment_date": appt_date.strftime("%Y-%m-%d"),
                "appointment_time": rng.choice(["09:00","10:00","11:00","14:00","15:00","16:00"]),
                "reason": rng.choice(["Routine Checkup","Follow-up","Consultation","Emergency","Lab Review"]),
                "status": rng.choice(statuses),
                "no_show_risk": round(risk_score, 2),
                "risk_label": risk_label,
                "previous_no_shows": prev_ns,
                "distance_km": dist,
                "sms_reminder_sent": sms,
                "booking_lead_days": lead,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            appt_id += 1

    pd.DataFrame(patients, columns=PATIENT_COLS).to_csv(PATIENTS_FILE, index=False)
    pd.DataFrame(appointments, columns=APPOINTMENT_COLS).to_csv(APPOINTMENTS_FILE, index=False)


def _doctor_name(did):
    mapping = {
        "D001":"Dr. Ananya Sharma","D002":"Dr. Rajesh Kumar","D003":"Dr. Priya Nair",
        "D004":"Dr. Suresh Menon","D005":"Dr. Kavitha Iyer","D006":"Dr. Arun Patel",
        "D007":"Dr. Meera Reddy","D008":"Dr. Vikram Singh"
    }
    return mapping.get(did, "Unknown")

def _doctor_dept(did):
    mapping = {
        "D001":"Cardiology","D002":"Neurology","D003":"Orthopedics",
        "D004":"General Medicine","D005":"Dermatology","D006":"Pediatrics",
        "D007":"Gynecology","D008":"Psychiatry"
    }
    return mapping.get(did, "General")

def _compute_risk(age, prev_no_shows, lead_days, distance_km, sms_sent):
    """Deterministic heuristic used for seeding (mirrors the ML model logic)."""
    score = 20.0
    score += min(prev_no_shows * 12, 40)
    if lead_days > 14: score += 10
    elif lead_days > 7: score += 5
    if distance_km > 30: score += 10
    elif distance_km > 15: score += 5
    if not sms_sent: score += 8
    if age < 25 or age > 65: score += 5
    return min(score, 100)


# ── Public API ───────────────────────────────────────────────────────────────
def initialize_db():
    if not os.path.exists(DOCTORS_FILE):
        _seed_doctors()
    if not os.path.exists(PATIENTS_FILE) or not os.path.exists(APPOINTMENTS_FILE):
        _seed_patients_and_appointments()


def load_patients() -> pd.DataFrame:
    initialize_db()
    return pd.read_csv(PATIENTS_FILE)

def load_appointments() -> pd.DataFrame:
    initialize_db()
    df = pd.read_csv(APPOINTMENTS_FILE)
    df["appointment_date"] = pd.to_datetime(df["appointment_date"])
    return df

def load_doctors() -> pd.DataFrame:
    initialize_db()
    return pd.read_csv(DOCTORS_FILE)


def save_patient(patient: dict):
    df = load_patients()
    if patient["patient_id"] in df["patient_id"].values:
        df = df[df["patient_id"] != patient["patient_id"]]
    new_row = pd.DataFrame([patient])
    df = pd.concat([df, new_row], ignore_index=True)
    df.to_csv(PATIENTS_FILE, index=False)


def save_appointment(appt: dict):
    df = load_appointments()
    if appt["appointment_id"] in df["appointment_id"].values:
        df = df[df["appointment_id"] != appt["appointment_id"]]
    new_row = pd.DataFrame([appt])
    new_row["appointment_date"] = pd.to_datetime(new_row["appointment_date"])
    df = pd.concat([df, new_row], ignore_index=True)
    df.to_csv(APPOINTMENTS_FILE, index=False)


def next_patient_id() -> str:
    df = load_patients()
    if df.empty:
        return "P001"
    ids = df["patient_id"].str.replace("P","").astype(int)
    return f"P{(ids.max()+1):03d}"

def next_appointment_id() -> str:
    df = load_appointments()
    if df.empty:
        return "A0001"
    ids = df["appointment_id"].str.replace("A","").astype(int)
    return f"A{(ids.max()+1):04d}"

def update_appointment_status(appt_id: str, new_status: str):
    df = load_appointments()
    df.loc[df["appointment_id"] == appt_id, "status"] = new_status
    df.to_csv(APPOINTMENTS_FILE, index=False)

def get_patient_appointments(patient_id: str) -> pd.DataFrame:
    df = load_appointments()
    return df[df["patient_id"] == patient_id].sort_values("appointment_date", ascending=False)

def get_patient_no_show_count(patient_id: str) -> int:
    df = get_patient_appointments(patient_id)
    return int((df["status"] == "No-Show").sum())
