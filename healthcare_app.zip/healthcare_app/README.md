# 🏥 Healthcare Appointment Management System

An **AI-powered, fully Streamlit-deployable** healthcare application for managing patient appointments, with an integrated **Gradient Boosting ML no-show risk predictor** and **Gemini 2.5 Flash** AI assistant.

---

## 🚀 Features

| Module | Capabilities |
|--------|-------------|
| **📅 Booking Module** | Patient registration, doctor/dept selection, slot booking, instant no-show risk, history view |
| **🏥 Admin Dashboard** | KPI metrics, Plotly charts, appointment management, doctor stats, CSV export |
| **🔮 Risk Predictor** | Individual + batch prediction, risk gauge, factor explanation, historical analysis |
| **🤖 Gemini 2.5 Flash AI** | Risk narratives, intervention advice, patient summaries, multi-turn admin chat |

---

## 🛠️ Setup & Run

### 1. Install dependencies
```bash
cd healthcare_app
pip install -r requirements.txt
```

### 2. Run the app
```bash
streamlit run app.py
```

### 3. Enter your Gemini API Key
- Visit [Google AI Studio](https://aistudio.google.com) → Get API Key (free)
- Paste it in the **sidebar → Gemini AI Setup** field
- AI features activate instantly (key stored in session only, never persisted)

---

## 📁 Project Structure

```
healthcare_app/
├── app.py                    # Main Streamlit entry point
├── requirements.txt
├── pages/
│   ├── booking.py            # Patient booking module
│   ├── admin_dashboard.py    # Admin analytics dashboard
│   └── risk_predictor.py     # Standalone risk predictor
├── models/
│   └── predictor.py          # GBM ML model + prediction API
├── utils/
│   ├── database.py           # CSV-based data layer (no DB needed)
│   └── gemini_helper.py      # Gemini 2.5 Flash integration
└── data/                     # Auto-created on first run
    ├── patients.csv
    ├── appointments.csv
    ├── doctors.csv
    └── noshow_model.pkl      # Trained model (auto-generated)
```

---

## 🤖 ML Model Details

- **Algorithm**: Gradient Boosting Classifier with Isotonic Calibration
- **Training Data**: 6,000 synthetic patient records
- **Features**: Age, previous no-shows, booking lead days, distance, SMS reminder, chronic conditions, time/day features, risk interaction term
- **Risk Thresholds**: Low (0–34) | Medium (35–64) | High (65–100)
- **Typical Performance**: ~85% accuracy, ~0.88 ROC-AUC

---

## 🌐 Streamlit Cloud Deployment

1. Push `healthcare_app/` to a GitHub repository
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Set **Main file path** to `healthcare_app/app.py`
4. Deploy — data CSVs are auto-generated on first run
5. Add your Gemini API key in the sidebar after deployment

> **Note**: On Streamlit Cloud, data resets on each app restart (ephemeral filesystem). For persistent storage, replace the CSV layer in `utils/database.py` with a cloud DB (e.g., Supabase, Firebase).

---

## ⚕️ Disclaimer

This application is for **educational and demonstration purposes only**. Always consult a licensed medical professional for healthcare decisions.
