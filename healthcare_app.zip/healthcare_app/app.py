"""
Main entry point – Healthcare Appointment Management System
Streamlit multi-page app with sidebar navigation.
"""

import streamlit as st
import os, sys

# ── Path setup ───────────────────────────────────────────────────────────────
APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title = "HealthCare Appointment Manager",
    page_icon  = "🏥",
    layout     = "wide",
    initial_sidebar_state = "expanded",
)

# ── Lazy imports (after path fix) ────────────────────────────────────────────
from utils.database import initialize_db

# Ensure data is seeded on first run
initialize_db()

# ════════════════════════════════════════════════════════════════════════════
# HOME PAGE FUNCTION (defined before routing so it's always available)
# ════════════════════════════════════════════════════════════════════════════
def _show_home():
    st.title("🏥 Healthcare Appointment Management System")
    st.markdown(
        "**AI-powered** appointment booking, administration, and no-show risk prediction "
        "using **Gemini 2.5 Flash** and **Machine Learning**."
    )

    st.markdown("---")

    # Feature cards
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown(
            """
            ### 📅 Booking Module
            - Patient registration
            - Doctor & department selection
            - Time slot booking
            - Instant no-show risk on booking
            - Appointment history view
            """
        )

    with col2:
        st.markdown(
            """
            ### 🏥 Admin Dashboard
            - Real-time KPI metrics
            - Interactive Plotly charts
            - Appointment management
            - Doctor performance stats
            - CSV export
            """
        )

    with col3:
        st.markdown(
            """
            ### 🔮 Risk Predictor
            - Individual & batch prediction
            - Gradient Boosting ML model
            - Risk gauge visualization
            - Historical pattern analysis
            - Factor explanation
            """
        )

    with col4:
        st.markdown(
            """
            ### 🤖 Gemini 2.5 Flash AI
            - Risk interpretation
            - Intervention recommendations
            - Patient summaries
            - Admin insights chat
            - Multi-turn conversation
            """
        )

    st.markdown("---")

    # Quick stats
    from utils.database import load_appointments, load_patients, load_doctors
    appts    = load_appointments()
    patients = load_patients()
    doctors  = load_doctors()

    st.subheader("📊 System Overview")
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Total Patients",      len(patients))
    m2.metric("Total Appointments",  len(appts))
    m3.metric("Registered Doctors",  len(doctors))
    m4.metric("Departments",         appts["department"].nunique() if not appts.empty else 0)

    if not appts.empty:
        ns_rate = round((appts["status"] == "No-Show").mean() * 100, 1)
        m5.metric("Overall No-Show Rate", f"{ns_rate}%")
    else:
        m5.metric("Overall No-Show Rate", "N/A")

    st.markdown("---")

    if not appts.empty:
        import plotly.express as px
        import pandas as pd

        col_a, col_b = st.columns(2)

        with col_a:
            st.markdown("#### Appointments by Department")
            dept_counts = appts["department"].value_counts().reset_index()
            dept_counts.columns = ["Department","Count"]
            fig = px.pie(dept_counts, values="Count", names="Department", hole=0.4)
            fig.update_layout(height=280, margin=dict(t=10,b=10))
            st.plotly_chart(fig, use_container_width=True)

        with col_b:
            st.markdown("#### Risk Level Distribution")
            risk_counts = appts["risk_label"].value_counts().reset_index()
            risk_counts.columns = ["Risk","Count"]
            fig2 = px.bar(
                risk_counts, x="Risk", y="Count",
                color="Risk",
                color_discrete_map={"Low":"#22c55e","Medium":"#f59e0b","High":"#ef4444"},
                text="Count"
            )
            fig2.update_traces(textposition="outside")
            fig2.update_layout(height=280, showlegend=False, margin=dict(t=10,b=10))
            st.plotly_chart(fig2, use_container_width=True)

    # Getting started
    st.markdown("---")
    st.info(
        "**Getting Started:**  \n"
        "1. 🔑 Enter your **Gemini API Key** in the sidebar to unlock AI features.  \n"
        "2. 📅 Go to **Book Appointment** to register as a patient and schedule an appointment.  \n"
        "3. 🏥 Visit **Admin Dashboard** to monitor all appointments and analytics.  \n"
        "4. 🔮 Use **Risk Predictor** for standalone no-show probability assessment."
    )


# ════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown(
        """
        <div style='text-align:center; padding: 8px 0 16px 0;'>
            <span style='font-size:2.4rem;'>🏥</span><br>
            <strong style='font-size:1.1rem;'>HealthCare AI</strong><br>
            <span style='font-size:0.78rem; color:#888;'>Appointment Management System</span>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.markdown("---")

    # Navigation
    page = st.radio(
        "Navigate",
        ["🏠 Home",
         "📅 Book Appointment",
         "🏥 Admin Dashboard",
         "🔮 Risk Predictor"],
        label_visibility="collapsed",
    )

    st.markdown("---")
    # Gemini API Key input
    st.markdown("### 🤖 Gemini AI Setup")
    api_key_input = st.text_input(
        "Gemini API Key",
        type="password",
        placeholder="AIza...",
        help="Get your free API key at https://aistudio.google.com",
        key="api_key_input_widget"
    )
    if api_key_input:
        st.session_state["gemini_api_key"] = api_key_input
        st.success("✅ API Key saved for this session")
    elif "gemini_api_key" not in st.session_state:
        st.session_state["gemini_api_key"] = ""

    if st.session_state.get("gemini_api_key"):
        st.markdown("🟢 **Gemini 2.5 Flash Active**")
    else:
        st.markdown("🔴 **AI features disabled** (enter key above)")

    st.markdown("---")
    st.markdown(
        "<div style='font-size:0.75rem; color:#999; text-align:center;'>"
        "Powered by Gemini 2.5 Flash<br>& Gradient Boosting ML<br><br>"
        "⚕️ For educational use only<br>"
        "Always consult a licensed physician"
        "</div>",
        unsafe_allow_html=True,
    )


# ════════════════════════════════════════════════════════════════════════════
# PAGE ROUTING
# ════════════════════════════════════════════════════════════════════════════
if page == "🏠 Home":
    _show_home()
elif page == "📅 Book Appointment":
    from pages.booking import show
    show()
elif page == "🏥 Admin Dashboard":
    from pages.admin_dashboard import show
    show()
elif page == "🔮 Risk Predictor":
    from pages.risk_predictor import show
    show()
